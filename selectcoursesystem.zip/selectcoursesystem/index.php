<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>欢迎来到选课系统！</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
	<div>
    	<h1>欢迎来到选课系统！请选择您的身份：</h1>
    </div>
<div>
    	<p><a href="login-stu.php">学生</a></p>
        <p><a href="login-tea.php">老师</a></p>
        <p><a href="login-admin.php">管理员</a></p>
    </div>
</body>
</html>
