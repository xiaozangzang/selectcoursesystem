<?php
if(!isset($_COOKIE["uid"])){
    header("location:index.php");
    exit();
}
?>